package com.example.myapplicationbutton;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {
    boolean isEgg=true;
    public void change(View view){

        ImageView iv=findViewById(R.id.imageView);
        if(isEgg) {
            iv.setImageResource(R.drawable.tom);
            isEgg = false;
        }else{
            iv.setImageResource(R.drawable.download);
            isEgg=true;
            }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}