abstract class Ducks{
    void swim(){
        System.out.println("ALL DUCKS CAN SWIM");
    }
    abstract void fly();
    abstract void quack();
}