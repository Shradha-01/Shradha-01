class WoodenDucks extends Ducks{
    void fly(){
        System.out.println("Wooden Ducks can not Fly");
    }
    void quack(){
        System.out.println("Wooden Duck is Mute");
    }
}