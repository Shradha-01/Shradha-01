class RedHeadDucks extends Ducks{
    void quack(){
        System.out.println("Red Head Ducks Quacks");
    }
    void fly(){
        System.out.println("Red Head Duck FLY");
    }
}