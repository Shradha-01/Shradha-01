public class Bheem extends Pandav{
    public void kind(){
        System.out.println("Less kind");
    }
}
