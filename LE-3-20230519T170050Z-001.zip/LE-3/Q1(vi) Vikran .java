public class Vikran extends Kauravs{
    public void obey(){
        System.out.println("Obedience");
    }
    public void kind(){
        System.out.println("kindness");
    }
}