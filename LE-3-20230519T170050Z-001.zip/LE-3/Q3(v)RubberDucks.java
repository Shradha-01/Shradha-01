class RubberDucks extends Ducks{
    void fly(){
        System.out.println("Rubber Ducks can not Fly");
    }
    void quack(){
        System.out.println("Rubber Duck squeaks");
    }
}