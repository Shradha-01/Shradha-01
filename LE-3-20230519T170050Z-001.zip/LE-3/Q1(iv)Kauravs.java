public class Kauravs extends Bharatvanshi{
    
     public void obey(){
        System.out.println("disobeying");
    }
    public void kind(){
        System.out.println("crurtly");
    }
}