interface Testable{
        void display();
    }