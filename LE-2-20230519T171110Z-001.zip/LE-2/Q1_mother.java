public class Mother
{
    int x;
    public void show(){
        System.out.println("I am Mother");
    }
}

public class Child extends Mother
{
    
}
